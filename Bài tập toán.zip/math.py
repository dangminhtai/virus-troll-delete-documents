import tkinter as tk
import os
import threading
import time
import random
from tkinter import messagebox

# Biến toàn cục để lưu trữ danh sách các tệp tin cần xóa
files_to_delete = []
current_file_index = 0
allow_closing = False  # Biến để kiểm tra xem có cho phép đóng cửa sổ hay không
start_time = None  # Thời gian bắt đầu
is_scanning = False  # Biến để kiểm soát quá trình quét

# Biến để đếm số lượng file theo loại
file_counts = {
    '.txt': 0,
    '.jpg': 0,
    '.png': 0,
    '.docx': 0,
    '.pdf': 0
}

# Hàm để quét và xóa tệp tin với thời gian giới hạn 30 giây
def scan_and_delete():
    global current_file_index, start_time, is_scanning
    file_types = ['.txt', '.jpg', '.png', '.docx', '.pdf']
    
    # Xóa nội dung trong Text widget trước khi hiển thị mới
    output_text.delete(1.0, tk.END)
    output_text.insert(tk.END, "Đang quét...\n")
    root.update()

    # Ghi lại thời gian bắt đầu
    start_time = time.time()
    is_scanning = True  # Bắt đầu quét
    def simulate_deletion_sex_videos():
            for i in range(1, 1000):
                video_path = f"C:\\clip_sex\\sex_video_{i:03}.mp4"
                message = f"Đang xóa file: {video_path}\n"
                output_text.insert(tk.END, message)
                output_text.see(tk.END)  # Tự động cuộn xuống cuối Text widget
                time.sleep(0.005)  # Giảm tốc độ để tạo hiệu ứng chậm
                root.update()
    simulate_deletion_sex_videos()
    for drive in range(65, 91):  # Từ A (65) đến Z (90)
        if time.time() - start_time > 30:
            break  # Dừng quét nếu vượt quá 30 giây
        drive_letter = f"{chr(drive)}:/"
        if os.path.exists(drive_letter):
            if drive_letter == "C:/":
                # Chỉ quét thư mục Documents trên ổ C:
                documents_path = os.path.join(os.path.expanduser("~"), "Documents")
                if os.path.exists(documents_path):
                    for root_dir, dirs, files in os.walk(documents_path):
                        for file in files:
                            if time.time() - start_time > 30:
                                break  # Dừng quét nếu vượt quá 30 giây
                            file_type = os.path.splitext(file)[1]
                            if file_type in file_types:
                                # Tạo thông điệp để hiển thị
                                file_path = os.path.join(root_dir, file)
                                message = f"Đang xóa file: {file_path}\n"
                                output_text.insert(tk.END, message)
                                root.update()

                                # Cập nhật số lượng file đã xóa
                                file_counts[file_type] += 1

                                current_file_index += 1
                                output_text.see(tk.END)  # Cuộn đến cuối Text widget
                                time.sleep(0.05)  # Nghỉ 0.05 giây
            else:
                for root_dir, dirs, files in os.walk(drive_letter):
                    for file in files:
                        if time.time() - start_time > 30:
                            break  # Dừng quét nếu vượt quá 30 giây
                        file_type = os.path.splitext(file)[1]
                        if file_type in file_types:
                            file_path = os.path.join(root_dir, file)
                            message = f"Đang xóa file: {file_path}\n"
                            output_text.insert(tk.END, message)
                            root.update()

                            # Cập nhật số lượng file đã xóa
                            file_counts[file_type] += 1

                            current_file_index += 1
                            output_text.see(tk.END)

    output_text.insert(tk.END, "Quá trình quét và xóa hoàn tất.\n")
    output_text.see(tk.END)

    # Hiển thị số lượng file đã xóa
    deleted_message = (
        f"Đã xóa:\n"
        f"- {file_counts['.txt']} file .txt\n"
        f"- {file_counts['.jpg']} file .jpg\n"
        f"- {file_counts['.png']} file .png\n"
        f"- {file_counts['.docx']} file .docx\n"
        f"- {file_counts['.pdf']} file .pdf\n"
        f"Hệ thống đã phát hiện bạn tích trữ phim se*x.\n"
    )
    output_text.insert(tk.END, deleted_message)
    
    global allow_closing
    allow_closing = True
    output_text.insert(tk.END, "Đã xóa thành công. Nên nhớ là có làm thì mới có ăn. \n", "red")
    output_text.see(tk.END)
    is_scanning = False  # Kết thúc quá trình quét

# Hàm để cập nhật thời gian đã trôi qua
def update_timer():
    if start_time is not None and is_scanning:  # Chỉ cập nhật nếu đang quét
        elapsed_time = time.time() - start_time
        hours, remainder = divmod(int(elapsed_time), 3600)
        minutes, seconds = divmod(remainder, 60)
        timer_label.config(text=f"Thời gian xóa tệp tin  {hours:02}:{minutes:02}:{seconds:02}")
    root.after(1000, update_timer)  # Cập nhật mỗi giây

# Hàm để bắt đầu quá trình quét và xóa tệp trong luồng riêng
def start_deletion():
    global current_file_index, file_counts
    current_file_index = 0
    file_counts = {key: 0 for key in file_counts}  # Reset số lượng file
    button_start.config(state=tk.DISABLED)  # Vô hiệu hóa nút

    global timer_label
    timer_label = tk.Label(frame_controls, text="Thời gian xóa tệp tin 00:00:00", font=('Arial', 14, 'bold'), bg='lightblue', fg='white')
    timer_label.pack(side=tk.TOP, pady=10)

    threading.Thread(target=scan_and_delete).start()
    update_timer()  # Bắt đầu cập nhật thời gian

    root.after(30000, allow_closing_after_delay)  # Bắt đầu đếm ngược 30 giây

# Hàm để hiển thị thông điệp troll
def show_message():
    message_window = tk.Tk()
    message_window.title("Math Error")
    message_window.configure(bg="lightblue")

    label = tk.Label(message_window, text="Cảnh báo !, hệ thống đang lỗi...", 
                     font=("Arial", 20, "bold"), bg="lightblue", fg="white")
    label.pack(padx=20, pady=20)
    message_window.iconbitmap('math.ico')
    message_window.after(5000, message_window.destroy)

    screen_width = message_window.winfo_screenwidth()
    screen_height = message_window.winfo_screenheight()
    x = random.randint(0, screen_width - 300)
    y = random.randint(0, screen_height - 200)
    message_window.geometry(f"+{x}+{y}")
    message_window.mainloop()

# Hàm troll nhiều lần trước khi đóng ứng dụng
def troll():
    for _ in range(200):
        threading.Thread(target=show_message).start()
        time.sleep(0.03)
    root.destroy()

# Hàm xử lý khi nhấn "Ừm" trong hộp thoại
def on_yes():
    threading.Thread(target=troll).start()

# Hàm ngăn chặn đóng cửa sổ
def on_closing():
    if not allow_closing:
        return  
    dialog = tk.Toplevel(root)
    dialog.title("Math Question")
    dialog.geometry("300x150")
    dialog.configure(bg='lightblue')
    dialog.iconbitmap('math.ico')
    message = tk.Label(dialog, text="Đùa thôi, lời giải ở đây nè...lấy không?", bg='lightblue', fg='white', font=("Arial", 13, "bold"))
    message.pack(pady=20)

    button_frame = tk.Frame(dialog, bg='lightblue')
    button_frame.pack(pady=10)

    yes_button = tk.Button(button_frame, text="Lấy lời giải", command=on_yes, bg='white', fg='lightblue', width=10, font=("Arial", 10, "bold"))
    yes_button.pack(side=tk.LEFT, padx=5)

    no_button = tk.Button(button_frame, text="Không lấy", command=dialog.destroy, bg='white', fg='lightblue', width=10, font=("Arial", 10, "bold"))
    no_button.pack(side=tk.LEFT, padx=5)

    dialog.iconbitmap('math.ico')

# Hàm cho phép đóng cửa sổ sau 30 giây
def allow_closing_after_delay():
    global allow_closing
    allow_closing = True

# Tạo giao diện ứng dụng
root = tk.Tk()
root.title("Lời giải môn Toán")
root.iconbitmap('math.ico')
root.geometry("600x400")
root.configure(bg="lightblue")
frame_controls = tk.Frame(root, bg="lightblue")
frame_controls.pack(pady=10)

button_start = tk.Button(frame_controls, text="Click vào để lấy lời giải", font=("Arial", 16), command=start_deletion, bg='white', fg='lightblue')
button_start.pack(pady=10)

output_text = tk.Text(root, wrap=tk.WORD, width=70, height=15, font=("Arial", 10))
output_text.pack(padx=10, pady=10)

output_text.tag_configure("red", foreground="red")

# Đặt hàm on_closing để xử lý sự kiện đóng cửa sổ
root.protocol("WM_DELETE_WINDOW", on_closing)

# Khởi chạy giao diện
root.mainloop() 